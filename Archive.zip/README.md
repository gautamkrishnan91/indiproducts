indiproducts
============

A service to help Indians choose products made in India over imported ones.


Yet to be done:

	Pages:
		-Brands
		-Categories
		-About
		-Stories
		-Blog
		-About
		-Feedback
		-Get Involved

	Elements:
		-Footer
		-Logo and Name for the service

	Facebook and Twitter branding
