<?php  echo"
<html>
	<head>";
		include 'headers.php';
        echo"
	</head>
	<body>";
		include 'header.php';
        echo"
 		<div id='content-wrapper'>
 			<div class='about-wrapper'>
 				
	 			<div class='about-main-photocontainer'>
	 				<div class='about-main-photo'></div>
	 				<div class='about-main-name'>Gautam Krishnan</div>
	 			</div>
	 			<div class='about-separator'>Founder</div>
	 			<div class='about-main-content'>
	 				Founder and CEO. Wafer ice cream apple pie fruitcake jelly-o sesame snaps cookie. Halvah cookie applicake tootsie roll topping gummies cheesecake liquorice. Danish chocolate gummies topping gummies marzipan fruitcake unerdwear.com tiramisu. Biscuit sweet roll cheesecake oat cake apple pie chocolate bar candy gingerbread icing. Candy chocolate liquorice. Tiramisu dragée candy canes sweet roll dragée.
	 			</div>
 			</div>
 		</div>
        ";
?>