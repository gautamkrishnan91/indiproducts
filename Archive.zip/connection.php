<?php
// Create connection
	$con = mysql_connect("mysql2.000webhost.com","a3538007_geekay","gautam123");

	if(!$con) die('General Connection Error!');									        //Setting up the database

    mysql_select_db ("a3538007_indiant", $con);

	// Check connection
	
	function check_input($value)
	{
	// Stripslashes
	if (get_magic_quotes_gpc())
	  {
	  $value = stripslashes($value);
	  }
	// Quote if not a number
	if (!is_numeric($value))
	  {
	  $value = mysql_real_escape_string($value);
	  }
	return $value;
	}
?>