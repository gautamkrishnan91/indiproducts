<?php echo" 
<link rel='stylesheet' type='text/css' href='css/reset.css'>
<link rel='stylesheet' type='text/css' href='css/style.css'>

<link rel='stylesheet' href='css/slider.css'>
<script src='js/jquery.min.js'></script>
<script src='js/notifications.js'></script>
<script src='js/dropdown.js'></script>
<script src='js/setheaderlink.js'></script>";
?>